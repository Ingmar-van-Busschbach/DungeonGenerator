﻿using NaughtyAttributes;
using System.Collections;
using UnityEngine;

public class DungeonGenerator : MonoBehaviour
{
    [Header("Maze Settings")]
    [SerializeField] private Vector2 mazeSize;

    [Space]
    [Header("Room Settings")]
    [SerializeField] private Vector2 roomMinSize;
    [SerializeField] private Vector2 roomMaxSize;
    [Range(0, 1)]
    [SerializeField] private float splitDirectionBias = 0.5f;
    [Range(0, 1)]
    [SerializeField] private float largeRoomChance = 0.1f;

    private BTEntry originBTEntry;

    private void Start()
    {
        GenerateDungeon();
    }
    private void Update()
    {
        DrawDungeon();
    }
    [Button(enabledMode: EButtonEnableMode.Playmode)]
    private void StartGeneration()
    {
        DebugDrawingBatcher.GetInstance().ClearAllBatchedCalls();
        StopAllCoroutines();
        GenerateDungeon();
    }
    private void GenerateDungeon()
    {
        originBTEntry = new BTEntry(null, new RectInt(0, 0, (int)mazeSize.x, (int)mazeSize.y));
        BTEntry currentBTEntry;
        currentBTEntry = originBTEntry;
        RectInt room = currentBTEntry.room;
        while (originBTEntry.complete != BTEntry.BTEntryStatus.Complete)
        {
            //Check if we completed the current entry since the last cycle. If we did, loop back to the parent.
            if (currentBTEntry.complete != BTEntry.BTEntryStatus.Complete)
            {
                currentBTEntry.CheckComplete();
            }
            if (currentBTEntry.complete == BTEntry.BTEntryStatus.Complete)
            {
                currentBTEntry = currentBTEntry.parent;
                continue;
            }
            //Check if the current entry can be divided into smaller rooms. If not, mark as completed.
            if (currentBTEntry.room.width < roomMinSize.x * 2 && currentBTEntry.room.height < roomMinSize.y * 2)
            {
                currentBTEntry.complete = BTEntry.BTEntryStatus.Complete;
                currentBTEntry.shouldDraw = true;
                room = currentBTEntry.room;
                //AlgorithmsUtils.DebugRectInt(currentBTEntry.room, Color.yellow, 10);
                continue;
            }
            //Select left room if generation was already done on the right branch but not on the left.
            if (currentBTEntry.right != null)
            {
                if (currentBTEntry.right.complete == BTEntry.BTEntryStatus.Complete && currentBTEntry.left.complete != BTEntry.BTEntryStatus.Complete)
                {
                    currentBTEntry = currentBTEntry.left;
                    continue;
                }
            }

            //Random chance to have larger rooms within the generated dungeon.
            if (Random.value < largeRoomChance)
            {
                if (currentBTEntry.room.width < roomMaxSize.x && currentBTEntry.room.height < roomMaxSize.y)
                {
                    currentBTEntry.complete = BTEntry.BTEntryStatus.Complete;
                    currentBTEntry.shouldDraw = true;
                    //AlgorithmsUtils.DebugRectInt(currentBTEntry.room, Color.yellow, 10); 
                    continue;
                }
            }
            //Split current room into two.
            currentBTEntry = SplitRoom(currentBTEntry);
        }
    }

    private BTEntry SplitRoom(BTEntry currentBTEntry)
    {
        //Randomly select whether to attempt to horizontally or vertically split first, then attempt splitting that way if the room is large enough.
        if (Random.value < splitDirectionBias)
        {
            if (currentBTEntry.room.width >= roomMinSize.x * 2)
            {
                return SplitHorizontally(currentBTEntry);
            }
            else
            {
                return SplitVertically(currentBTEntry);
            }
        }
        else
        {
            if (currentBTEntry.room.height >= roomMinSize.y * 2)
            {
                return SplitVertically(currentBTEntry);
            }
            else
            {
                return SplitHorizontally(currentBTEntry);
            }
        }
    }
    
    private BTEntry SplitHorizontally(BTEntry currentBTEntry)
    {
        int splitPointX = (int)Random.Range(roomMinSize.x, currentBTEntry.room.width - roomMinSize.x);
        currentBTEntry.right = new BTEntry(currentBTEntry, new RectInt(currentBTEntry.room.position.x, currentBTEntry.room.position.y, splitPointX, currentBTEntry.room.height));
        currentBTEntry.left = new BTEntry(currentBTEntry, new RectInt(currentBTEntry.room.position.x + splitPointX, currentBTEntry.room.position.y, currentBTEntry.room.width - splitPointX, currentBTEntry.room.height));
        return currentBTEntry.right;
    }

    private BTEntry SplitVertically(BTEntry currentBTEntry)
    {
        int splitPointY = (int)Random.Range(roomMinSize.y, currentBTEntry.room.height - roomMinSize.y);
        currentBTEntry.right = new BTEntry(currentBTEntry, new RectInt(currentBTEntry.room.position.x, currentBTEntry.room.position.y, currentBTEntry.room.width, splitPointY));
        currentBTEntry.left = new BTEntry(currentBTEntry, new RectInt(currentBTEntry.room.position.x, currentBTEntry.room.position.y + splitPointY, currentBTEntry.room.width, currentBTEntry.room.height - splitPointY));
        return currentBTEntry.right;
    }

    private void DrawDungeon()
    {
        BTEntry currentBTEntry;
        currentBTEntry = originBTEntry;
        while (!originBTEntry.drawn)
        {
            if (currentBTEntry.right != null)
            {
                if (!currentBTEntry.right.drawn)
                {
                    currentBTEntry = currentBTEntry.right;
                    continue;
                }
            }
            if (currentBTEntry.left != null)
            {
                if (!currentBTEntry.left.drawn)
                {
                    currentBTEntry = currentBTEntry.left;
                    continue;
                }
            }
            if (currentBTEntry.shouldDraw)
            {
                AlgorithmsUtils.DebugRectInt(currentBTEntry.room, Color.yellow, 30f);
            }
            currentBTEntry.drawn = true;
            currentBTEntry = currentBTEntry.parent;
        }
    }
}
